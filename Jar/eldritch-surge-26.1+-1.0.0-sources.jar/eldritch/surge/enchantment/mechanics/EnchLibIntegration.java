package eldritch.surge.enchantment.mechanics;

import eldritch.surge.EldritchSurge;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Optional bridge to EnchLib; both mods keep their own runtime and JAR. */
public final class EnchLibIntegration {
    private EnchLibIntegration() {
    }

    public static void synchronizeEnchantments() {
        if (!FabricLoader.getInstance().isModLoaded("enchlib")) {
            EldritchSurge.LOGGER.info("EnchLib not installed; skipping optional enchantment sync.");
            return;
        }

        Map<String, Integer> maxLevels = new TreeMap<>();
        Map<String, List<String>> categories = new TreeMap<>();
        Map<String, List<String>> mobCategories = new TreeMap<>();
        for (ModEnchantmentDefinition definition : ModEnchantmentDefinitions.ALL) {
            String id = EldritchSurge.MOD_ID + ":" + definition.id();
            maxLevels.put(id, definition.maxLevel());
            categories.put(id, definition.supportedItems());
        }

        mobCategories.put("eldritch-surge:bane_of_end", List.of("void"));
        mobCategories.put("eldritch-surge:blade_of_apocalypse", List.of("animals", "undead", "void", "hell", "water"));
        mobCategories.put("eldritch-surge:butcher", List.of("animals"));
        mobCategories.put("eldritch-surge:creeping_threat", List.of("arthropods"));
        mobCategories.put("eldritch-surge:exorcist", List.of("hell"));
        mobCategories.put("eldritch-surge:flogging", List.of("rebel"));
        mobCategories.put("eldritch-surge:herbicide", List.of("fungi"));
        mobCategories.put("eldritch-surge:smoother", List.of("cubic"));
        mobCategories.put("eldritch-surge:undead_slayer", List.of("undead"));
        mobCategories.put("eldritch-surge:witch_hunter", List.of("magik"));
        mobCategories.put("eldritch-surge:wrath_of_the_abyss", List.of("water"));

        // Extend vanilla Smite to EnchLib's undead category and expose the target category there too.
        maxLevels.put("minecraft:smite", 5);
        categories.put("minecraft:smite", List.of("#minecraft:enchantable/weapon"));
        mobCategories.put("minecraft:smite", List.of("undead"));

        try {
            Class<?> api = Class.forName("goldenrose01.enchlib.api.EnchantLibAPI");
            try {
                Method register = api.getMethod("registerEnchantments", Map.class, Map.class, Map.class);
                Object count = register.invoke(null, maxLevels, categories, mobCategories);
                EldritchSurge.LOGGER.info("Registered {} enchantment entries with EnchLib.", count);
            } catch (NoSuchMethodException olderApi) {
                Method register = api.getMethod("registerEnchantments", Map.class, Map.class);
                Object count = register.invoke(null, maxLevels, categories);
                EldritchSurge.LOGGER.warn("EnchLib API is outdated; target mob categories were not synchronized ({} entries).", count);
            }
        } catch (ReflectiveOperationException | LinkageError exception) {
            EldritchSurge.LOGGER.error("EnchLib was found but its enchantment API could not be called.", exception);
        }
    }
}
