package eldritch.surge.creative;

import eldritch.surge.EldritchSurge;
import eldritch.surge.block.EldritchBlocks;
import eldritch.surge.config.EnchantmentCapsConfig;
import eldritch.surge.enchantment.mechanics.ModEnchantmentDefinition;
import eldritch.surge.enchantment.mechanics.ModEnchantmentDefinitions;
import eldritch.surge.enchantment.mechanics.SpellBookItems;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import eldritch.surge.item.EldritchItems;

import java.util.Comparator;
import java.util.Locale;
import java.util.Map;

public final class EldritchCreativeTabs {
    private static final Map<String, ModEnchantmentDefinition> DEFINITIONS = ModEnchantmentDefinitions.BY_ID;

    public static final ResourceKey<CreativeModeTab> MELEE_WEAPONS_KEY = key("melee_weapons");
    public static final ResourceKey<CreativeModeTab> TOOLS_KEY = key("tools");
    public static final ResourceKey<CreativeModeTab> RANGED_WEAPONS_KEY = key("ranged_weapons");
    public static final ResourceKey<CreativeModeTab> BOWS_KEY = key("bows");
    public static final ResourceKey<CreativeModeTab> ARMOR_KEY = key("armor");
    public static final ResourceKey<CreativeModeTab> EXTRA_KEY = key("extra");

    public static final CreativeModeTab MELEE_WEAPONS = register(
            MELEE_WEAPONS_KEY,
            "itemGroup.eldrich-surge.melee_weapons",
            Items.DIAMOND_SWORD,
            CreativeCategory.MELEE_WEAPONS
    );
    public static final CreativeModeTab TOOLS = register(
            TOOLS_KEY,
            "itemGroup.eldrich-surge.tools",
            Items.DIAMOND_PICKAXE,
            CreativeCategory.TOOLS
    );
    public static final CreativeModeTab RANGED_WEAPONS = register(
            RANGED_WEAPONS_KEY,
            "itemGroup.eldrich-surge.ranged_weapons",
            Items.TRIDENT,
            CreativeCategory.RANGED_WEAPONS
    );
    public static final CreativeModeTab BOWS = register(
            BOWS_KEY,
            "itemGroup.eldrich-surge.bows",
            Items.BOW,
            CreativeCategory.BOWS
    );
    public static final CreativeModeTab ARMOR = register(
            ARMOR_KEY,
            "itemGroup.eldrich-surge.armor",
            Items.DIAMOND_CHESTPLATE,
            CreativeCategory.ARMOR
    );
    public static final CreativeModeTab EXTRA = register(
            EXTRA_KEY,
            "itemGroup.eldrich-surge.extra",
            Items.ENCHANTED_BOOK,
            CreativeCategory.EXTRA
    );

    private EldritchCreativeTabs() {
    }

    public static void initialize() {
        EldritchSurge.LOGGER.debug("Registered Eldritch Surge creative tabs.");
    }

    private static ResourceKey<CreativeModeTab> key(String path) {
        return ResourceKey.create(Registries.CREATIVE_MODE_TAB, EldritchSurge.id(path));
    }

    private static CreativeModeTab register(
            ResourceKey<CreativeModeTab> key,
            String titleKey,
            net.minecraft.world.item.Item icon,
            CreativeCategory category
    ) {
        return Registry.register(
                BuiltInRegistries.CREATIVE_MODE_TAB,
                key,
                FabricCreativeModeTab.builder()
                        .title(Component.translatable(titleKey))
                        .icon(() -> {
                            ItemStack iconStack = new ItemStack(icon);
                            if (category == CreativeCategory.TOOLS) {
                                iconStack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
                            }
                            return iconStack;
                        })
                        .displayItems((parameters, output) -> {
                            if (category == CreativeCategory.EXTRA) {
                                output.accept(EldritchBlocks.ADVANCED_ENCHANTING_TABLE_ITEM);
                            }

                            parameters.holders()
                                    .lookupOrThrow(Registries.ENCHANTMENT)
                                    .listElements()
                                    .filter(enchantment -> belongsTo(enchantment, category))
                                    .sorted(Comparator.comparing(EldritchCreativeTabs::sortKey)
                                            .thenComparing(EldritchCreativeTabs::idSortKey))
                                    .forEach(enchantment -> {
                                        output.accept(createMaxLevelBook(enchantment), CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
                                    });
                        })
                        .build()
        );
    }

    private static ItemStack createMaxLevelBook(Holder<Enchantment> enchantment) {
        int maxLevel = maxCreativeLevel(enchantment);
        ItemStack book;
        if (SpellBookItems.isCastSpell(enchantment)) {
            book = new ItemStack(EldritchItems.SPELL_BOOK);
            book.enchant(enchantment, maxLevel);
        } else {
            book = EnchantmentHelper.createBook(new EnchantmentInstance(enchantment, maxLevel));
        }
        SpellBookItems.markIfSpellBook(book);
        return book;
    }

    private static int maxCreativeLevel(Holder<Enchantment> enchantment) {
        int registeredMaximum = Math.max(1, enchantment.value().getMaxLevel());
        return enchantment.unwrapKey()
                .map(key -> Math.max(1, EnchantmentCapsConfig.resolveAnvilCap(key.identifier(), registeredMaximum)))
                .orElse(registeredMaximum);
    }

    private static String sortKey(Holder.Reference<Enchantment> enchantment) {
        return enchantment.value().description().getString().toLowerCase(Locale.ROOT);
    }

    private static String idSortKey(Holder.Reference<Enchantment> enchantment) {
        return enchantment.unwrapKey()
                .map(key -> key.identifier().toString())
                .orElseGet(() -> enchantment.value().description().getString());
    }

    private static boolean belongsTo(Holder.Reference<Enchantment> enchantment, CreativeCategory category) {
        return enchantment.unwrapKey()
                .map(key -> {
                    if (!key.identifier().getNamespace().equals(EldritchSurge.MOD_ID)) {
                        return false;
                    }

                    ModEnchantmentDefinition definition = DEFINITIONS.get(key.identifier().getPath());
                    return definition != null && categoryOf(definition) == category;
                })
                .orElse(false);
    }

    static CreativeCategory categoryOf(ModEnchantmentDefinition definition) {
        return CreativeEnchantmentClassifier.categoryOf(definition);
    }

}
