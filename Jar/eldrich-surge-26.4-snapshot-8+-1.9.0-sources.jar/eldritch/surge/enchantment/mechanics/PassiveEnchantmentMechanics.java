package eldritch.surge.enchantment.mechanics;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ShulkerBoxBlock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class PassiveEnchantmentMechanics {
    private static final Identifier ARMORED_ARMOR = Identifier.fromNamespaceAndPath("eldrich-surge", "armored_armor");
    private static final Identifier EXCAVATOR_BLOCK_RANGE = Identifier.fromNamespaceAndPath("eldrich-surge", "excavator_block_range");
    private static final Identifier EXCAVATOR_ENTITY_RANGE = Identifier.fromNamespaceAndPath("eldrich-surge", "excavator_entity_range");
    private static final Identifier RABBIT_FOOT_LUCK = Identifier.fromNamespaceAndPath("eldrich-surge", "rabbit_foot_luck");
    private static final Identifier SWIFTNESS_SPEED = Identifier.fromNamespaceAndPath("eldrich-surge", "swiftness_speed");
    private static final Identifier HICKER_STEP_HEIGHT = Identifier.fromNamespaceAndPath("eldrich-surge", "hicker_step_height");
    private static final Identifier ICE_SPEED_MODIFIER = Identifier.fromNamespaceAndPath("eldrich-surge", "ice_speed_modifier");
    private static final Map<UUID, Set<UUID>> SEEKER_TARGETS = new HashMap<>();
    private static final Map<UUID, ItemEntity> SEEKER_ITEMS = new HashMap<>();
    private static final Map<UUID, Integer> SEEKER_ITEM_REFERENCES = new HashMap<>();

    private PassiveEnchantmentMechanics() {
    }

    public static void initialize() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            SEEKER_TARGETS.clear();
            SEEKER_ITEMS.clear();
            SEEKER_ITEM_REFERENCES.clear();
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> releaseSeekerTargets(handler.player.getUUID()));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                applyPlayerPassives((ServerLevel) player.level(), player);
                if (player.tickCount % 5 == 0) {
                    applyArmored(player);
                    applyExcavator(player);
                    applyOffhandAndLuckModifiers(player);
                    updateSeekerGlow((ServerLevel) player.level(), player);
                }
            }
        });
    }

    private static void applyPlayerPassives(ServerLevel level, ServerPlayer player) {
        int combustion = EnchantmentLevels.onArmor(level, player, "combustion_protection");
        if (combustion > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, Math.min(1, combustion - 1), true, false, true));
            player.clearFire();
        }

        int vision = EnchantmentLevels.onArmor(level, player, "vision_blessing");
        if (vision > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, true, false, true));
        }

        int health = EnchantmentLevels.onArmor(level, player, "health_upgrade");
        if (health > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 80, EnchantmentLevels.armorAmplifier(level, player, "health_upgrade", 4), true, false, true));
        }

        int sea = EnchantmentLevels.onArmor(level, player, "heart_of_the_sea");
        if (sea > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.CONDUIT_POWER, 80, EnchantmentLevels.armorAmplifier(level, player, "heart_of_the_sea", 1), true, false, true));
            player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 80, EnchantmentLevels.armorAmplifier(level, player, "heart_of_the_sea", 1), true, false, true));
        }

        int night = EnchantmentLevels.onArmor(level, player, "blessing_of_the_night");
        long dayTime = level.getOverworldClockTime() % 24000L;
        if (night > 0 && dayTime >= 13000L && dayTime <= 23000L && player.tickCount % 1200 == 0) {
            ExperienceOrb.award(level, player.position(), night * 5);
        }

        int sun = EnchantmentLevels.onArmor(level, player, "sun_blessing");
        if (sun > 0 && level.dimension() == Level.OVERWORLD && dayTime < 12000L
                && level.canSeeSkyFromBelowWater(player.blockPosition()) && player.tickCount % 1200 == 0) {
            ExperienceOrb.award(level, player.position(), sun * 10);
        }

        int hell = EnchantmentLevels.onArmor(level, player, "hell_blessing");
        if (hell > 0 && (player.isInLava() || player.isOnFire()) && player.tickCount % 20 == 0) {
            ExperienceOrb.award(level, player.position(), hell * 10);
        }

        int hicker = EnchantmentLevels.onArmor(level, player, "hicker");
        updateModifierAmount(player, Attributes.STEP_HEIGHT, HICKER_STEP_HEIGHT, hicker > 0 ? 0.5D * hicker : 0.0D);

        int dash = EnchantmentLevels.onArmor(level, player, "dash");
        if (dash > 0 && player.isSprinting()) {
            player.addEffect(new MobEffectInstance(MobEffects.SPEED, 40, EnchantmentLevels.armorAmplifier(level, player, "dash", 2), true, false, true));
        }

        int iceSpeed = EnchantmentLevels.onArmor(level, player, "ice_speed");
        double iceBoost = iceSpeed > 0 && isOnIceOrSnow(level, player) ? 0.064D * iceSpeed : 0.0D;
        updateModifierAmount(player, Attributes.MOVEMENT_SPEED, ICE_SPEED_MODIFIER, iceBoost);

        ItemStack chargingItem = player.isUsingItem() ? player.getUseItem() : ItemStack.EMPTY;
        double swiftness = swiftnessOnChargingWeapon(level, chargingItem);
        updateModifierAmount(player, Attributes.MOVEMENT_SPEED, SWIFTNESS_SPEED, 0.1D * swiftness);

        int healingAura = EnchantmentLevels.onArmor(level, player, "healing_aura");
        if (healingAura > 0 && player.isShiftKeyDown() && player.tickCount % 40 == 0) {
            for (ServerPlayer nearby : level.players()) {
                if (nearby.distanceToSqr(player) <= 36.0D && nearby.getHealth() < nearby.getMaxHealth()) {
                    nearby.heal(1.0F + healingAura);
                }
            }
        }

        if (player.tickCount % 10 == 0) {
            applyInventoryAutomation(level, player);
        }
    }

    private static void applyInventoryAutomation(ServerLevel level, ServerPlayer player) {
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack shulker = player.getInventory().getItem(slot);
            if (!isShulker(shulker)) {
                continue;
            }

            if (EnchantmentLevels.onItem(level, shulker, "refill") > 0) {
                refillMainHand(player, shulker);
            }
        }
    }

    private static void applyArmored(ServerPlayer player) {
        double level = player.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA)
                ? EnchantmentLevels.onArmorStrength(player.level(), player, "armored")
                : 0;
        updateModifierAmount(player, Attributes.ARMOR, ARMORED_ARMOR, level * 2.0D);
    }

    private static void applyExcavator(ServerPlayer player) {
        double level = EnchantmentLevels.onItemStrength(player.level(), player.getMainHandItem(), "excavator")
                + EnchantmentLevels.onItemStrength(player.level(), player.getOffhandItem(), "excavator");
        updateModifier(player, Attributes.BLOCK_INTERACTION_RANGE, EXCAVATOR_BLOCK_RANGE, level);
        updateModifier(player, Attributes.ENTITY_INTERACTION_RANGE, EXCAVATOR_ENTITY_RANGE, level);
    }

    private static void applyOffhandAndLuckModifiers(ServerPlayer player) {
        double rabbitFoot = EnchantmentLevels.onArmorStrength(player.level(), player, "rabbit_foot");
        updateModifier(player, Attributes.LUCK, RABBIT_FOOT_LUCK, rabbitFoot);
    }

    private static void updateSeekerGlow(ServerLevel level, ServerPlayer player) {
        int seeker = EnchantmentLevels.onArmor(level, player, "seeker_blessing");
        Set<UUID> current = new HashSet<>();
        if (seeker > 0) {
            for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class,
                    player.getBoundingBox().inflate(Math.min(64.0D, 2.0D * seeker)))) {
                item.setGlowingTag(true);
                current.add(item.getUUID());
                SEEKER_ITEMS.put(item.getUUID(), item);
            }
        }
        Set<UUID> previous = SEEKER_TARGETS.put(player.getUUID(), current);
        if (previous != null) {
            for (UUID id : previous) if (!current.contains(id)) releaseSeekerItem(id);
        }
        if (previous == null) {
            for (UUID id : current) SEEKER_ITEM_REFERENCES.merge(id, 1, Integer::sum);
        } else {
            for (UUID id : current) {
                if (!previous.contains(id)) SEEKER_ITEM_REFERENCES.merge(id, 1, Integer::sum);
            }
        }
    }

    private static void releaseSeekerTargets(UUID playerId) {
        Set<UUID> previous = SEEKER_TARGETS.remove(playerId);
        if (previous != null) for (UUID itemId : previous) releaseSeekerItem(itemId);
    }

    private static void releaseSeekerItem(UUID itemId) {
        Integer references = SEEKER_ITEM_REFERENCES.get(itemId);
        if (references == null || references <= 1) {
            SEEKER_ITEM_REFERENCES.remove(itemId);
            ItemEntity item = SEEKER_ITEMS.remove(itemId);
            if (item != null && item.isAlive()) item.setGlowingTag(false);
        } else {
            SEEKER_ITEM_REFERENCES.put(itemId, references - 1);
        }
    }

    private static void updateModifier(ServerPlayer player, net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attributeKey, Identifier id, double level) {
        updateModifierAmount(player, attributeKey, id, level);
    }

    private static double swiftnessOnChargingWeapon(ServerLevel level, ItemStack stack) {
        if (!stack.is(ItemTags.BOW_ENCHANTABLE) && !stack.is(ItemTags.SPEARS)) return 0;
        return EnchantmentLevels.onItemStrength(level, stack, "swiftness");
    }

    private static void updateModifierAmount(ServerPlayer player,
            net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attributeKey,
            Identifier id, double amount) {
        TransientAttributeModifiers.set(player.getAttribute(attributeKey), id, amount <= 0.0D ? 0.0D : amount);
    }

    private static boolean isOnIceOrSnow(ServerLevel level, ServerPlayer player) {
        return isIceOrSnowBlock(level.getBlockState(player.blockPosition()))
                || isIceOrSnowBlock(level.getBlockState(player.getBlockPosBelowThatAffectsMyMovement()));
    }

    private static boolean isIceOrSnowBlock(net.minecraft.world.level.block.state.BlockState state) {
        if (state.isAir()) {
            return false;
        }
        if (state.is(net.minecraft.tags.BlockTags.ICE) || state.is(net.minecraft.tags.BlockTags.SNOW)) {
            return true;
        }
        String path = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
        return path.contains("ice") || path.contains("snow");
    }

    public static boolean trySiphonPickup(ServerLevel level, ServerPlayer player, ItemEntity itemEntity) {
        if (itemEntity.hasPickUpDelay()) {
            return false;
        }
        ItemStack remaining = itemEntity.getItem().copy();
        boolean changed = false;

        for (int slot = 0; slot < player.getInventory().getContainerSize() && !remaining.isEmpty(); slot++) {
            ItemStack shulker = player.getInventory().getItem(slot);
            if (shulker != player.getOffhandItem()
                    && isShulker(shulker)
                    && EnchantmentLevels.onItem(level, shulker, "siphon") > 0) {
                ItemStack next = siphonIntoPartialStacks(shulker, remaining);
                if (next.getCount() != remaining.getCount()) {
                    remaining = next;
                    changed = true;
                }
            }
        }

        ItemStack offhand = player.getOffhandItem();
        if (!remaining.isEmpty() && isShulker(offhand) && EnchantmentLevels.onItem(level, offhand, "siphon") > 0) {
            ItemStack next = siphonIntoPartialStacks(offhand, remaining);
            if (next.getCount() != remaining.getCount()) {
                remaining = next;
                changed = true;
            }
        }

        for (int slot = 0; slot < player.getInventory().getContainerSize() && !remaining.isEmpty(); slot++) {
            ItemStack shulker = player.getInventory().getItem(slot);
            if (shulker != player.getOffhandItem()
                    && isShulker(shulker)
                    && EnchantmentLevels.onItem(level, shulker, "vacuum") > 0) {
                ItemStack next = vacuumIntoShulker(shulker, remaining);
                if (next.getCount() != remaining.getCount()) {
                    remaining = next;
                    changed = true;
                }
            }
        }

        if (!remaining.isEmpty() && isShulker(offhand) && EnchantmentLevels.onItem(level, offhand, "vacuum") > 0) {
            ItemStack next = vacuumIntoShulker(offhand, remaining);
            if (next.getCount() != remaining.getCount()) {
                remaining = next;
                changed = true;
            }
        }

        if (!changed) {
            return false;
        }

        if (remaining.isEmpty()) {
            itemEntity.discard();
            return true;
        }
        itemEntity.setItem(remaining);
        return false;
    }

    private static ItemStack siphonIntoPartialStacks(ItemStack shulker, ItemStack incoming) {
        NonNullList<ItemStack> contents = shulkerContents(shulker);
        ItemStack remaining = incoming.copy();
        boolean changed = false;

        for (ItemStack stored : contents) {
            if (remaining.isEmpty()) {
                break;
            }

            if (!stored.isEmpty()
                    && ItemStack.isSameItemSameComponents(stored, remaining)
                    && stored.getCount() < stored.getMaxStackSize()) {
                int moved = Math.min(remaining.getCount(), stored.getMaxStackSize() - stored.getCount());
                stored.grow(moved);
                remaining.shrink(moved);
                changed = true;
            }
        }

        if (changed) {
            saveShulkerContents(shulker, contents);
        }
        return remaining;
    }

    private static void refillMainHand(ServerPlayer player, ItemStack shulker) {
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty() || held.getCount() >= held.getMaxStackSize()) {
            return;
        }

        NonNullList<ItemStack> contents = shulkerContents(shulker);
        for (int index = 0; index < contents.size(); index++) {
            ItemStack stored = contents.get(index);
            if (!stored.isEmpty() && ItemStack.isSameItemSameComponents(held, stored)) {
                stored.shrink(1);
                held.grow(1);
                saveShulkerContents(shulker, contents);
                return;
            }
        }
    }

    private static ItemStack vacuumIntoShulker(ItemStack shulker, ItemStack incoming) {
        NonNullList<ItemStack> contents = shulkerContents(shulker);
        ItemStack remaining = insert(contents, incoming);
        if (remaining.getCount() != incoming.getCount()) {
            saveShulkerContents(shulker, contents);
        }
        return remaining;
    }

    private static ItemStack insert(NonNullList<ItemStack> contents, ItemStack stack) {
        ItemStack remaining = stack.copy();
        for (ItemStack stored : contents) {
            if (remaining.isEmpty()) {
                return ItemStack.EMPTY;
            }

            if (!stored.isEmpty() && ItemStack.isSameItemSameComponents(stored, remaining) && stored.getCount() < stored.getMaxStackSize()) {
                int moved = Math.min(remaining.getCount(), stored.getMaxStackSize() - stored.getCount());
                stored.grow(moved);
                remaining.shrink(moved);
            }
        }

        for (int index = 0; index < contents.size(); index++) {
            if (remaining.isEmpty()) {
                return ItemStack.EMPTY;
            }

            if (contents.get(index).isEmpty()) {
                int moved = Math.min(remaining.getCount(), remaining.getMaxStackSize());
                contents.set(index, remaining.copyWithCount(moved));
                remaining.shrink(moved);
            }
        }

        return remaining;
    }

    private static NonNullList<ItemStack> shulkerContents(ItemStack shulker) {
        NonNullList<ItemStack> contents = NonNullList.withSize(27, ItemStack.EMPTY);
        ItemContainerContents component = shulker.getOrDefault(DataComponents.CONTAINER, ItemContainerContents.EMPTY);
        component.copyInto(contents);
        return contents;
    }

    private static void saveShulkerContents(ItemStack shulker, NonNullList<ItemStack> contents) {
        shulker.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(new ArrayList<>(contents)));
    }

    private static boolean isShulker(ItemStack stack) {
        return stack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() instanceof ShulkerBoxBlock;
    }
}
